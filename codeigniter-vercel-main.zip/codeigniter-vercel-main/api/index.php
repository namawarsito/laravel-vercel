<?php 

// Forward vercel request to normal index.php
require __DIR__.'/../index.php';
